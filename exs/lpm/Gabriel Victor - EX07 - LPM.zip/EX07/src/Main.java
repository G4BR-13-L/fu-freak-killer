import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.Scanner;

import Business.Biblioteca;
import Business.Cliente;
import Business.Livro;
import dao.ClienteDAO;
import dao.DAO;
import dao.LivroDAO;

public class Main {
    public static void main(String[] args) throws IOException {
        Biblioteca biblioteca = new Biblioteca();
        File fileLivros = new File("./Data/Livros.txt");
        Scanner sc1 = new Scanner(fileLivros);
        while (sc1.hasNext()) {
            String linha = sc1.nextLine();
            String[] partes = linha.split(";");
            String codigo = partes[0];
            String titulo = partes[1];
            Livro livro = new Livro(codigo, titulo);
            livro.adicionarABiblioteca();
        }
        sc1.close();

        File fileCliente = new File("./Data/Clientes.txt");
        Scanner sc2 = new Scanner(fileCliente);
        while (sc2.hasNext()) {
            String linha = sc2.nextLine();
            String[] partes = linha.split(";");
            String matricula = partes[0];
            String nome = partes[1];
            Cliente cliente = new Cliente(matricula, nome);
            cliente.matricular();
        }
        sc2.close();

        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("DSBLVRN4"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("LJ7AD37D"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("ADS7ZK5P"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("D279IVGE"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("70WT64GO"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("96KHUL73"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("1VKB30XI"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("X38AAT13"));
        biblioteca.getCliente("Q4E8A7").fazerEmprestimo(biblioteca.getLivro("6UDYSI0Z"));
        biblioteca.getCliente("N81I30").fazerEmprestimo(biblioteca.getLivro("8R0WB267"));
        biblioteca.getCliente("6E87ZK").fazerEmprestimo(biblioteca.getLivro("I70RTI47"));
        biblioteca.getCliente("NVCZD4").fazerEmprestimo(biblioteca.getLivro("RQCO839F"));
        biblioteca.getCliente("L0Y9IT").fazerEmprestimo(biblioteca.getLivro("QKIGJO3V"));
        biblioteca.getCliente("2SHDPX").fazerEmprestimo(biblioteca.getLivro("KC6BLJIU"));
        biblioteca.getCliente("JVMHXC").fazerEmprestimo(biblioteca.getLivro("EMDERJCB"));
        biblioteca.getCliente("ZP240C").fazerEmprestimo(biblioteca.getLivro("ZYK36NI5"));
        biblioteca.getCliente("D16413").fazerEmprestimo(biblioteca.getLivro("0FK8ZXSI"));
        biblioteca.getCliente("3IN3WK").fazerEmprestimo(biblioteca.getLivro("Q24CSAAG"));
        biblioteca.getCliente("5P8IJ4").fazerEmprestimo(biblioteca.getLivro("CYEQI01I"));
        biblioteca.getCliente("JA20Z3").fazerEmprestimo(biblioteca.getLivro("DQ8BAC4H"));

        System.out.println("RELATORIO DE TODOS OS EMPRESTIMOS DE APENAS UM CLIENTE\n\n");
        System.out.println(biblioteca.getCliente("Q4E8A7").toString());

        System.out.println("\n\nRELATORIO DE TODOS OS EMPRESTIMOS DA BIBLIOTECA\n\n");

        System.out.println(biblioteca.getListaDeEmprestimos());

        System.out.println("\n\nSALVANDO OBJETOS DE CLIENTES EM ARQUIVOS\n\n");

        DAO<Cliente, String> clientesDao = new ClienteDAO("Clientes.bin");

        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("Q4E8A7"));
        clientesDao.add(biblioteca.getCliente("N81I30"));
        clientesDao.add(biblioteca.getCliente("6E87ZK"));
        clientesDao.add(biblioteca.getCliente("NVCZD4"));
        clientesDao.add(biblioteca.getCliente("L0Y9IT"));
        clientesDao.add(biblioteca.getCliente("2SHDPX"));
        clientesDao.add(biblioteca.getCliente("JVMHXC"));
        clientesDao.add(biblioteca.getCliente("ZP240C"));
        clientesDao.add(biblioteca.getCliente("D16413"));
        clientesDao.add(biblioteca.getCliente("3IN3WK"));
        clientesDao.add(biblioteca.getCliente("5P8IJ4"));
        clientesDao.add(biblioteca.getCliente("JA20Z3"));

        System.out.println("\n\nSALVANDO OBJETOS DE LIVROS EM ARQUIVOS\n\n");
        DAO<Livro, String> livrosDao = new LivroDAO("Livros.bin");

        livrosDao.add(biblioteca.getLivro("DSBLVRN4"));
        livrosDao.add(biblioteca.getLivro("LJ7AD37D"));
        livrosDao.add(biblioteca.getLivro("ADS7ZK5P"));
        livrosDao.add(biblioteca.getLivro("D279IVGE"));
        livrosDao.add(biblioteca.getLivro("70WT64GO"));
        livrosDao.add(biblioteca.getLivro("96KHUL73"));
        livrosDao.add(biblioteca.getLivro("1VKB30XI"));
        livrosDao.add(biblioteca.getLivro("X38AAT13"));
        livrosDao.add(biblioteca.getLivro("6UDYSI0Z"));
        livrosDao.add(biblioteca.getLivro("8R0WB267"));
        livrosDao.add(biblioteca.getLivro("I70RTI47"));
        livrosDao.add(biblioteca.getLivro("RQCO839F"));
        livrosDao.add(biblioteca.getLivro("QKIGJO3V"));
        livrosDao.add(biblioteca.getLivro("KC6BLJIU"));
        livrosDao.add(biblioteca.getLivro("EMDERJCB"));
        livrosDao.add(biblioteca.getLivro("ZYK36NI5"));
        livrosDao.add(biblioteca.getLivro("0FK8ZXSI"));
        livrosDao.add(biblioteca.getLivro("Q24CSAAG"));
        livrosDao.add(biblioteca.getLivro("CYEQI01I"));
        livrosDao.add(biblioteca.getLivro("DQ8BAC4H"));

    }

    public static String gerarCodigo(int length) {
        char[] characterSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
        Random random = new SecureRandom();
        char[] result = new char[length];
        for (int i = 0; i < result.length; i++) {
            int randomCharIndex = random.nextInt(characterSet.length);
            result[i] = characterSet[randomCharIndex];
        }
        return new String(result);
    }

    public static void gerador() {
        String[] livros = {
                "Introduction to Algorithms",
                "The Art of Computer Programming",
                "Compilers",
                "The Design and Evolution of C++",
                "Object Oriented Analysis and Design",
                "The Unified Software Development Process",
                "UML Distilled",
                "Refactoring",
                "Agile",
                "Extreme Programming Explained",
                "Clean Code",
                "The Clean Coder",
                "The Pragmatic Programmer",
                "Design Patterns",
                "Patterns of Enterprise Application Patterns",
                "Domain Driven Design",
                "The Lean Startup",
                "The Mythical Man-Month",
                "Hobbit ",
                "O Senhor dos Anéis",
                "O Silmarillion",
                "Contos Inacabados",
                "As Aventuras de Tom Bombadil",
                "Os Filhos de Húrin",
                "The history of Middle-earth: The Book of Lost Tales Part I",
                "The history of Middle-earth: The Book of Lost Tales Part II",
                "The history of Middle-earth: The Lays of Beleriand",
                "The history of Middle-earth: The Shaping of Middle-earth",
                "The history of Middle-earth: The Lost Road and Other Writings",
                "The history of Middle-earth: The Return of the Shadow",
                "The history of Middle-earth: The Treason of Isengard",
                "The history of Middle-earth: The War of the Ring",
                "The history of Middle-earth: Sauron Defeated",
                "The history of Middle-earth: Morgoth’s Ring",
                "The history of Middle-earth: The War of the Jewels",
                "The history of Middle-earth: The People’s of Middle-earth",
                "The History of Middle-earth Index",
                "Beowulf (tradução comentada)",
                "Sir Gawain and the Green Knight (tradução)",
                "Finn and Hengest (estudo)",
                "The Monsters and the Critics (ensaio)",
                "Tolkien On Fairy-stories (expanded edition)",
                "Mestre Gil de Ham",
                "Cartas do Papai Noel ",
                "Roverandom (ed. Brasileira)",
                "Ferreiro de Bosque Grande",
                "A Lenda de Sigurd & Gudrún",
                "A Queda de Artur",
                "A História de Kullervo",
                "Sr. Bliss",
                "A Última Canção de Bilbo ",
                "Poemas de O Senhor dos Anéis",
                "J. R. R. Tolkien Artist & Illustrator",
                "The Art of The Hobbit",
                "The Art of The Lord of the Rings",
                "Beren and Lúthien",
                "The Lay of Aotrou & Itroun",
                "As Cartas de J. R. R. Tolkien",
        };

        String[] nomes = {
                "Costello",
                "Kid Richards",
                "Party Poison",
                "Morrison",
                "Matt Davu",
                "Mumford",
                "Jimmy",
                "Bowie",
                "Monkey",
                "Manson",
                "Dianury",
                "John Beacon",
                "Korne",
                "Blood Sandwich",
                "Alice",
                "Blackout",
                "Ramone",
                "Cohen",
                "Iggy",
                "Primal Scream",
                "Monolith",
                "Gojira",
                "Smoke and Mirrors",
                "Ringo",
                "Rile Nodger",
                "Springstone",
                "Turner",
                "Bowie",
                "Metalic",

        };

        /*
         * for (int i = 0; i < livros.length; i++) {
         * System.out.println(gerarCodigo(8) + ";" + livros[i]);
         * }
         */
        for (int i = 0; i < nomes.length; i++) {
            System.out.println(gerarCodigo(6) + ";" + nomes[i]);
        }
    }
}