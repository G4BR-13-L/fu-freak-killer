public interface IPlanoDeSaude{
    double calcMensalidade(int idade);
    double coparticipacao();
}