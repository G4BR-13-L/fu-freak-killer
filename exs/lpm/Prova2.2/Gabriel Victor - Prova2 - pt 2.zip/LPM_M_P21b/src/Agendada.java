/*
=====================================================
Código desenvolvido por:
 ██████╗  █████╗ ██████╗ ██████╗ ██╗███████╗██╗
██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║██╔════╝██║
██║  ███╗███████║██████╔╝██████╔╝██║█████╗  ██║
██║   ██║██╔══██║██╔══██╗██╔══██╗██║██╔══╝  ██║
╚██████╔╝██║  ██║██████╔╝██║  ██║██║███████╗███████╗
 ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝
 =====================================================
*/
import java.time.LocalDate;

public class Agendada extends Consulta {

    public Agendada(LocalDate data, Especialidade espec) {
        super(data, espec);
        this.valorPago = this.valorAPagar();
        //TODO Auto-generated constructor stub
    }

    @Override
    public double valorAPagar() {
        return this.especialidade.preco(this.especialidade);
    }

}
