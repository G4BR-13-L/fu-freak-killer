public class Cliente {
    public String nome;
    private Jogo[] historico;
    private int qtdJogos;
    
    Cliente(String nome){
        this.nome = nome;
        historico = new Jogo[100];
        this.qtdJogos = 0;
    }
    
    public void incluirJogo( Jogo novoJogo ){
        this.historico[this.qtdJogos] = novoJogo;
        this.qtdJogos++;
    }

    public Jogo[] getHistorico() {
        return historico;
    }

    public String toString(){

        String buff = "----- CLIENTE -----\nNome: "+this.nome+
        "\nHistorico:";
        for ( int i  = 0 ; i < this.qtdJogos ; i++ ){
            buff+="\n- "+this.historico[i].toString();
        }
        return buff;
    }

}
