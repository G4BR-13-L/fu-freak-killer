import java.time.LocalDateTime;

public class Jogo {
    // Atributos especificados no enunciado
    private static final int TEMPO_DESC = 2;
    private static final double PCT_DESCONTO = 0.2;
    private static final double MARGEM_LUCRO = 0.35;
    protected String nome;
    protected int anoLancamento;
    protected double precoBase;
    protected int[] avaliacoes;
    
    // Atibutos adicionais
    public static final int ANO_ATUAL = 2022;
    private int anoAtual;
    private double precoOriginal;
    private int qtdAvaliacoes; 
    public String modalidade = "Download";
    
    
    Jogo(String nome,  int anoLancamento, double precoBase ){
        this.setPrecoBase(precoBase);
        this.setPrecoOriginal(precoBase);
        this.setAnoLancamento(anoLancamento);
        this.setNome(nome);
        this.setAnoAtual(ANO_ATUAL);
        this.avaliacoes = new int[100];
        this.qtdAvaliacoes = 0;


    }

    public void incrementarAnos(int anos){
        this.setAnoAtual(this.anoAtual+anos);
        this.descontoTempo();
    }
    public void incrementarAnos(){
        this.incrementarAnos(this.anoAtual+1);
        this.descontoTempo();
    }
    private void setAnoAtual(int ano) {
        this.anoAtual = ano;
        this.descontoTempo();
    }

    public double precoVenda(){
        return this.precoBase * (MARGEM_LUCRO*1);
    }

    protected double precoBase(){
        return this.precoBase;
    }

    private void descontoTempo(){
      if (this.anoLancamento != anoAtual){
          int diff = this.anoAtual - this.anoLancamento;
          int descontosASeremAplicados = diff / 2;
          for( int i = 0 ; i < descontosASeremAplicados ; i++ ){
              this.precoBase -= this.precoBase * PCT_DESCONTO;
          }
      }  
    }

    public double avaliacaoMedia(){
        int soma = 0;
        for ( int i = 0 ;  i < qtdAvaliacoes ; i++  ){
            soma+=this.avaliacoes[i];
        }
        return soma / qtdAvaliacoes;
    }

    public void notaAvaliacao(int nota){
        if ( nota < 1 ){
            this.avaliacoes[this.qtdAvaliacoes] = 1;
        }else if( nota > 5) {
            this.avaliacoes[this.qtdAvaliacoes] = 5;
        }else{
            this.avaliacoes[this.qtdAvaliacoes] = nota;
        }
        this.qtdAvaliacoes++;
    }

    public String toString(){
        return "-----\nTitulo: "+this.getNome()+
        "\n\tAno de lancamento: "+this.getAnoLancamento()+
        "\n\tAno de Compra: "+this.anoAtual+
        "\n\tPreco original: "+this.precoOriginal+
        "\n\tPreco base: "+this.getPrecoBase()+
        "\n\tPreco de venda: "+this.precoVenda()+
        "\n-----";

    }

    
    public String getNome() {
        return nome;
    }
    private void setNome(String nome) {
        this.nome = nome;
    }
    public int getAnoLancamento() {
        return anoLancamento;
    }
    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }
    public double getPrecoBase() {
        return precoBase;
    }
    public void setPrecoBase(double precoBase) {
        this.precoBase = precoBase;
    }
    public int[] getAvaliacoes() {
        return avaliacoes;
    }
    public void setAvaliacoes(int[] avaliacoes) {
        this.avaliacoes = avaliacoes;
    }
    private void setPrecoOriginal(double precoOriginal){
        this.precoOriginal = precoOriginal;
    }

}
