public class Main{
    public static void main(String[] args) {

        System.out.println("Desenvolvido por: Gabriel Victor");
        System.out.println("\n\n1. Instanciando novo cliente..");
        System.out.println("\n2. Verificando estado atual do cliente:");
        Cliente cliente = new Cliente("Gabriel");
        System.out.println(cliente.toString());
        System.out.println("\n3. Instanciando 2 jogos: Batman e Assassin's Creed:");
        Jogo ac = new Jogo("Assassin's Creed", 2020, 200);
        Jogo batman = new Jogo("Batman", 2021, 350);
        System.out.println("\n3. Cliente comprando jogos...");
        cliente.incluirJogo(batman);
        cliente.incluirJogo(ac);
        System.out.println("\n4. Verificando estado atual do cliente novamente:");
        System.out.println(cliente.toString());
        System.out.println("");


    }
}