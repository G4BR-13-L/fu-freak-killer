import Cliente.Cliente;
import Jogo.Jogo;
import Jogo.JogoDigital;
import Jogo.JogoFisico;

public class Main{
    public static void main(String[] args) {

        System.out.println("Desenvolvido por: Gabriel Victor");
        System.out.println("\n\n1. Instanciando novo cliente..");
        System.out.println("\n2. Verificando estado atual do cliente:");
        Cliente cliente = new Cliente("Gabriel");
        System.out.println(cliente.toString());
        System.out.println("\n3. Instanciando 8 jogos: Batman e Assassin's Creed:");
        JogoFisico ac = new JogoFisico("Assassin's Creed", 2020, 280, 2, true);
        JogoDigital batman = new JogoDigital("Batman", 2021, 350);
        JogoFisico MetalGear = new JogoFisico("Metal Gear Solid V", 2015, 200, 2, true);
        JogoDigital Forza = new JogoDigital("Forza", 2020, 350);
        JogoFisico StarWars = new JogoFisico("Star Wars", 2019, 200, 2, false);
        JogoDigital GTA = new JogoDigital("GTA", 2013, 250);
        JogoFisico Halo = new JogoFisico("Halo", 2020, 300, 2, false);
        JogoFisico Miranha = new JogoFisico("Homem-Aranha", 2018, 350, 2, true);
        System.out.println("\n3. Cliente comprando jogos...");
        cliente.incluirJogo(batman);
        cliente.incluirJogo(ac);
        cliente.incluirJogo(MetalGear);
        cliente.incluirJogo(Forza);
        cliente.incluirJogo(StarWars);
        cliente.incluirJogo(GTA);
        cliente.incluirJogo(Halo);
        cliente.incluirJogo(Miranha);     
        System.out.println("\n4. Verificando estado atual do cliente novamente:");
        System.out.println(cliente.toString());
        System.out.println("");


    }
}