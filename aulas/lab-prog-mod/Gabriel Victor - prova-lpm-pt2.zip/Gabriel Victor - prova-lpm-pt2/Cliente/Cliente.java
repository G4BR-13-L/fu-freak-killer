package Cliente;
import Jogo.Jogo;

public class Cliente {
    public String nome;
    private Jogo[] historico;
    private int qtdJogos;

    private double valorParaGanharDesconto;

    public Cliente(String nome) {
        this.nome = nome;
        historico = new Jogo[100];
        this.qtdJogos = 0;
        this.setValorParaGanharDesconto(0);
    }

    public void incluirJogo(Jogo novoJogo) {
        if (this.isElegivelParaDesconto()) {
            novoJogo.aplicarDesconto();
            this.historico[this.qtdJogos] = novoJogo;
            this.qtdJogos++;
            this.setValorParaGanharDesconto(0);
        }else{
            this.setValorParaGanharDesconto(this.getValorParaGanharDesconto() + novoJogo.precoVenda());
            this.historico[this.qtdJogos] = novoJogo;
            this.qtdJogos++;
        }
    }

    public Jogo[] getHistorico() {
        return historico;
    }

    public Jogo getJogo(int index){
        if ( index >= 0 && index <= 100 ){
            return this.historico[index];
        }else{
            return this.historico[0];
        }
    }

    public String toString() {

        String buff = "----- CLIENTE -----\nNome: " + this.nome +
                "\nHistorico:";
        for (int i = 0; i < this.qtdJogos; i++) {
            buff += "\n- " + this.historico[i].toString();
        }
        return buff;
    }

    public double getValorParaGanharDesconto() {
        return valorParaGanharDesconto;
    }

    public void setValorParaGanharDesconto(double valorParaGanharDesconto) {
        this.valorParaGanharDesconto = valorParaGanharDesconto;
    }

    public boolean isElegivelParaDesconto() {
        return this.getValorParaGanharDesconto() >= 500;
    }

}
