package Jogo;
public class JogoDigital extends Jogo{

    public JogoDigital(String nome,  int anoLancamento, double precoBase){
        super(nome, anoLancamento, precoBase);
    }

    public double precoVenda(){
        return this.precoBase * (Jogo.MARGEM_LUCRO+1);
    }

    @Override
    public String toString(){
        //double precoComDesconto;
        if ( super.getPrecoVendaComDesconto() == 0 ){
            super.setPrecoVendaComDesconto(this.precoVenda());
        } 
        return "-----\nTitulo: "+this.getNome()+
        "\n\tTipo: Jogo Digital"+
        "\n\tAno de lancamento: "+this.getAnoLancamento()+
        "\n\tAno de Compra: "+this.getAnoAtual()+
        "\n\tPreco original: R$"+this.getPrecoBase()+
        "\n\tPreco base: R$"+this.getPrecoBase()+
        "\n\tPreco de venda: R$"+this.precoVenda()+
        "\n\tPreco de venda com desconto: R$"+super.getPrecoVendaComDesconto()+
        "\n-----";

    }
}
