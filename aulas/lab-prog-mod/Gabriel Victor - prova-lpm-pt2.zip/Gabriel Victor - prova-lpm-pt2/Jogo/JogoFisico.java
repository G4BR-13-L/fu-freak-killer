package Jogo;
public class JogoFisico extends Jogo{

    private static final double ADIC_DISCO = 15;
    private static final double ACRES_ESPECIAL = 0.10; 

    private int quantDiscos;
    private boolean isVersaoEspecial;

    public JogoFisico(String nome,  int anoLancamento, double precoBase, int quantDiscos, boolean versaoEspecial ){
        super(nome, anoLancamento, precoBase);
        this.setQuantDiscos(quantDiscos);
        this.setVersaoEspecial(isVersaoEspecial);
    }

    public double precoVenda(){
        if(this.isIsVersaoEspecial()){
            return (this.precoBase * (Jogo.MARGEM_LUCRO+1))+
            (this.getQuantDiscos()*this.ADIC_DISCO)*(this.ACRES_ESPECIAL+1);
        }else{
            return (this.precoBase * (Jogo.MARGEM_LUCRO+1))+
            (this.getQuantDiscos()*this.ADIC_DISCO);
        }
    }

    @Override
    public String toString(){
        //double precoComDesconto;
        if ( super.getPrecoVendaComDesconto() == 0 ){
            this.setPrecoVendaComDesconto(this.precoVenda());
        } 
        return "-----\nTitulo: "+this.getNome()+
        "\n\tTipo: Jogo Fisico"+
        "\n\tQuantidade de Discos: "+this.getQuantDiscos()+
        "\n\tAno de lancamento: "+this.getAnoLancamento()+
        "\n\tAno de Compra: "+this.getAnoAtual()+
        "\n\tPreco original: R$"+this.getPrecoBase()+
        "\n\tPreco base: R$"+this.getPrecoBase()+
        "\n\tPreco de venda: R$"+this.precoVenda()+
        "\n\tPreco de venda com desconto: R$"+this.getPrecoVendaComDesconto()+
        "\n-----";

    }

 
    public int getQuantDiscos() {
        return quantDiscos;
    }

    public void setQuantDiscos(int quantDiscos) {
        this.quantDiscos = quantDiscos;
    }

    public boolean isIsVersaoEspecial() {
        return isVersaoEspecial;
    }

    public void setVersaoEspecial(boolean isVersaoEspecial) {
        this.isVersaoEspecial = isVersaoEspecial;
    }

}
