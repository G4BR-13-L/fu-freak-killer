package tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;

import Cliente.Cliente;
import Jogo.JogoDigital;
import Jogo.JogoFisico;

public class JogoTest {
    JogoFisico jogo1;
    Cliente cliente;

    @BeforeEach
    public void setup() {
        jogo1 = new JogoFisico("Star Wars", 2020, 200, 2, false);
        cliente = new Cliente("Gabriel");
    }

    /*
     * Titulo: Star Wars
     * Tipo: Jogo Fisico
     * Quantidade de Discos: 2
     * Ano de lancamento: 2019
     * Ano de Compra: 2022
     * Preco original: R$160.0
     * Preco base: R$160.0
     * Preco de venda: R$86.0
     * Preco de venda com desconto: R$86.0
     */
    @Test
    public void verificarPrecoJogoFisico() {
        assertEquals(200.0, jogo1.getPrecoOriginal());
        assertEquals(160.0, jogo1.getPrecoBase());
        assertEquals(246.0, jogo1.precoVenda());
    }

    @Test
    public void testarDescontoDe500(){
        JogoFisico jogo2 = new JogoFisico("Batman", 2020, 490, 3, true);
        cliente.incluirJogo(jogo2);
        assertEquals(true, cliente.isElegivelParaDesconto());
        JogoDigital jogo3 = new JogoDigital("Batman 2 ", 2021, 100);
        cliente.incluirJogo(jogo3);
        assertEquals(108.0, cliente.getJogo(1).getPrecoVendaComDesconto());
        
    }
}
